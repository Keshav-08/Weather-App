package com.example.weatherappprojectfinal;

import androidx.appcompat.app.AppCompatActivity;

import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.weatherappprojectfinal.R;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;

public class MainActivity extends AppCompatActivity {
    EditText editText;
    Button enter;
    JSONObject zipCode;
    String getBuffered;
    String getBuffered2;
    JSONObject whole;
    TextView city;

    TextView latitude;
    TextView longitude;
    TextView quote;
    TextView currentLowTemperature;
    TextView currentHighTemperature;
    TextView lowTemperature2;
    TextView highTemperature2;
    TextView lowTemperature3;
    TextView highTemperature3;
    TextView lowTemperature4;
    TextView highTemperature4;
    TextView lowTemperature5;
    TextView highTemperature5;
    TextView currentTime;
    TextView time2;
    TextView time3;
    TextView time4;
    TextView time5;
    ImageView currentWeather;
    ImageView temperature2;
    ImageView temperature3;
    ImageView temperature4;
    ImageView temperature5;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        enter = findViewById(R.id.button);
        editText = findViewById(R.id.editText);
        city = findViewById(R.id.city);
        latitude = findViewById(R.id.latitude);
        longitude = findViewById(R.id.longitude);
        currentLowTemperature = findViewById(R.id.currentLowTemperature);
        currentHighTemperature = findViewById(R.id.currentHighTemperature);
        lowTemperature2 = findViewById(R.id.lowTemperature2);
        highTemperature2 = findViewById(R.id.highTemperature2);
        lowTemperature3 = findViewById(R.id.lowTemperature3);
        highTemperature3 = findViewById(R.id.highTemperature3);
        lowTemperature4 = findViewById(R.id.lowTemperature4);
        highTemperature4 = findViewById(R.id.highTemperature4);
        lowTemperature5 = findViewById(R.id.lowTemperature5);
        highTemperature5 = findViewById(R.id.highTemperature5);
        currentTime = findViewById(R.id.currentTime);
        time2 = findViewById(R.id.time2);
        time3 = findViewById(R.id.time3);
        time4 = findViewById(R.id.time4);
        time5 = findViewById(R.id.time5);
        currentWeather = findViewById(R.id.currentWeather);
        temperature2 = findViewById(R.id.temperature2);
        temperature3 = findViewById(R.id.temperature3);
        temperature4 = findViewById(R.id.temperature4);
        temperature5 = findViewById(R.id.temperature5);
        quote = findViewById(R.id.quote);

        enter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AsyncThread asyncThread = new AsyncThread();
                asyncThread.execute(String.valueOf(editText.getText()));

            }
        });

    }

    public class AsyncThread extends AsyncTask<String,Void, JSONObject>{

        @Override
        protected JSONObject doInBackground(String... strings) {
            try {
                URL Url = new URL("https://api.openweathermap.org/geo/1.0/zip?zip=" + strings[0] + ",US&appid=7dec3be36871db757d2198d250b25345");
                URLConnection URLConnection = Url.openConnection();
                InputStream InputStream = URLConnection.getInputStream();
                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(InputStream));
                String lineReader;
                getBuffered = bufferedReader.readLine();
                while ((lineReader = bufferedReader.readLine()) != null)
                    getBuffered += lineReader;

                zipCode = new JSONObject(getBuffered);
                String lat = zipCode.getString("lat");
                String lon = zipCode.getString("lon");
                URL Url2 = new URL("https://api.openweathermap.org/data/2.5/forecast?lat=" + lat + "&lon=" + lon + "&appid=7dec3be36871db757d2198d250b25345");
                URLConnection URLConnection2 = Url2.openConnection();
                InputStream InputStream2 = URLConnection2.getInputStream();
                BufferedReader bufferedReader2 = new BufferedReader(new InputStreamReader(InputStream2));
                String lineReader2;
                getBuffered2 = bufferedReader2.readLine();
                while((lineReader2 = bufferedReader2.readLine()) != null)
                    getBuffered2 += lineReader2;

                whole = new JSONObject(getBuffered2);



            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();
            }
            return whole;

        }

        protected void onPostExecute(JSONObject whole){
            try {
                city.setText(whole.getJSONObject("city").getString("name"));
                latitude.setText("Lat: " + whole.getJSONObject("city").getJSONObject("coord").getString("lat"));
                longitude.setText("Lon: " + whole.getJSONObject("city").getJSONObject("coord").getString("lon"));
                currentLowTemperature.setText("Low: " + lowTemperature(whole,0));
                currentHighTemperature.setText("High: " + highTemperature(whole,0));
                lowTemperature2.setText("Low: " + lowTemperature(whole,1));
                highTemperature2.setText("High: " + highTemperature(whole,1));
                lowTemperature3.setText("Low: " + lowTemperature(whole,2));
                highTemperature3.setText("High: " + highTemperature(whole,2));
                lowTemperature4.setText("Low: " + lowTemperature(whole,3));
                highTemperature4.setText("High: " + highTemperature(whole,3));
                lowTemperature5.setText("Low: " + lowTemperature(whole,4));
                highTemperature5.setText("High: " + highTemperature(whole,4));
                currentTime.setText(Time(whole,0));
                time2.setText(Time(whole,1));
                time3.setText(Time(whole,2));
                time4.setText(Time(whole,3));
                time5.setText(Time(whole,4));
                currentWeather.setImageResource(Image(whole,0));
                temperature2.setImageResource(Image(whole,1));
                temperature3.setImageResource(Image(whole,2));
                temperature4.setImageResource(Image(whole,3));
                temperature5.setImageResource(Image(whole,4));
                quote.setText(Quote(whole));
            } catch (JSONException e) {
                e.printStackTrace();
            }

        }
    }

    public String lowTemperature(JSONObject a, int i ) throws JSONException {
        double lowTempK = a.getJSONArray("list").getJSONObject(i).getJSONObject("main").getDouble("temp_min");
        double lowTempF = 1.8 * (lowTempK - 273) + 32;
        lowTempF = (double)Math.round(lowTempF * 100.0) / 100.0;
        return String.valueOf(lowTempF);
    }
    public String highTemperature(JSONObject a, int i ) throws JSONException {
        double highTempK = a.getJSONArray("list").getJSONObject(i).getJSONObject("main").getDouble("temp_max");
        double highTempF = 1.8 * (highTempK - 273) + 32;
        highTempF = (double)Math.round(highTempF * 100.0) / 100.0;
        return String.valueOf(highTempF);
    }
    public String Time(JSONObject a, int i) throws JSONException {
        String time = a.getJSONArray("list").getJSONObject(i).getString("dt_txt").substring(11,13);
        int est = Integer.parseInt(time) - 5;
        if(est == 0){
            time = "12:00 am";
            return time;
        }
        else if(est == 12){
            time= "12:00 pm";
            return time;
        }
        else if(est > 12){
            est -= 12;
            time = est + ":00 pm";
            return time;
        }
        else if(est < 0){
            time = (est + 10) + ":00 pm";
            return time;
        }
        else{
            time = est + ":00 am";
            return time;
        }

    }
    public int Image(JSONObject a, int i) throws JSONException {
        String weather = a.getJSONArray("list").getJSONObject(0).getJSONArray("weather").getJSONObject(0).getString("description");
        if(weather.equals("clear sky"))
            return R.drawable.clear;
        if(weather.equals("few clouds"))
            return R.drawable.clouds1;
        if(weather.equals("scattered clouds"))
            return R.drawable.clouds2;
        if(weather.equals("broken clouds"))
            return R.drawable.clouds3;
        if(weather.equals("shower rain"))
            return R.drawable.shower;
        if(weather.equals("rain"))
            return R.drawable.rain;
        if(weather.equals("thunderstorm"))
            return R.drawable.thunderstorm;
        if(weather.equals("snow"))
            return R.drawable.snow;
        if(weather.equals("mist"))
            return R.drawable.mist;

        return R.drawable.clear;

    }

    public String Quote(JSONObject a) throws JSONException {
        String weather = a.getJSONArray("list").getJSONObject(0).getJSONArray("weather").getJSONObject(0).getString("description");
        if(weather.equals("clear sky")) {
            int random = (int)(Math.random()*1);
            if(random == 1)
                return "Charizard used Sunny Day!";
            else
                return "Charizard uses flamethrower increasing the heat in the terrain";
        }
        if(weather.equals("few clouds"))
            return "Watch out for wild Castform they disguise themself in the clouds";
        if(weather.equals("scattered clouds"))
            return "Ho-oh appears from the clouds bringing a rainbow with it";
        if(weather.equals("broken clouds"))
            return "Altaria's hidden ability Cloud Nine removes the clouds";
        if(weather.equals("shower rain"))
            return "Torrent's ability Drizzle summons rain on the battle field";
        if(weather.equals("rain"))
            return "Blastoise uses Rain Dance!";
        if(weather.equals("thunderstorm"))
            return "Pikachu dodge and use Thunderbolt!";
        if(weather.equals("snow"))
            return "Glalie uses Blizzard, it was very effective!";
        if(weather.equals("mist"))
            return "The terrain is covered in fog, have your Staraptor use Defog";

        return "";

    }}


